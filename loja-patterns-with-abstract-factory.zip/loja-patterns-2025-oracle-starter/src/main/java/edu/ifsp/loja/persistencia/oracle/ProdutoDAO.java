package edu.ifsp.loja.persistencia.oracle;

import edu.ifsp.loja.modelo.Produto;
import edu.ifsp.loja.persistencia.dao.ProdutoDAO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAOOracle implements ProdutoDAO {

    private Connection connection;

    public ProdutoDAOOracle(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void inserir(Produto produto) throws SQLException {
        String sql = "INSERT INTO PRODUTO (NOME, PRECO) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, produto.getNome());
            stmt.setDouble(2, produto.getPreco());
            stmt.executeUpdate();
        }
    }

    @Override
    public List<Produto> listar() throws SQLException {
        List<Produto> produtos = new ArrayList<>();
        String sql = "SELECT * FROM PRODUTO";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Produto p = new Produto();
                p.setId(rs.getInt("ID"));
                p.setNome(rs.getString("NOME"));
                p.setPreco(rs.getDouble("PRECO"));
                produtos.add(p);
            }
        }
        return produtos;
    }
}
