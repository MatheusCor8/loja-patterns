package edu.ifsp.loja.persistencia.factory;

import edu.ifsp.loja.persistencia.dao.ClienteDAO;
import edu.ifsp.loja.persistencia.dao.ProdutoDAO;
import edu.ifsp.loja.persistencia.oracle.*;

public class OracleDatabaseFactory implements DatabaseFactory {
    @Override
    public ClienteDAO createClienteDAO() {
        return new ClienteDAO();
    }

    @Override
    public ProdutoDAO createProdutoDAO() {
        return new ProdutoDAO();
    }
}
