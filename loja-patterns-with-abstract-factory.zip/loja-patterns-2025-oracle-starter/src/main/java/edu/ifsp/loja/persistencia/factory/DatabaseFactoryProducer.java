package edu.ifsp.loja.persistencia.factory;

import java.io.InputStream;
import java.util.Properties;

public class DatabaseFactoryProducer {

    public static DatabaseFactory getFactory() {
        String dbType = null;

        try (InputStream input = DatabaseFactoryProducer.class.getClassLoader()
                .getResourceAsStream("config.properties")) {

            if (input != null) {
                Properties prop = new Properties();
                prop.load(input);
                dbType = prop.getProperty("database.type");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (dbType == null || dbType.isEmpty()) {
            dbType = System.getenv("DATABASE_TYPE");
        }

        if (dbType == null || dbType.isEmpty()) {
            dbType = "mysql";
        }

        switch (dbType.toLowerCase()) {
            case "oracle":
                return new OracleDatabaseFactory();
            case "mysql":
            default:
                return new MySQLDatabaseFactory();
        }
    }
}
