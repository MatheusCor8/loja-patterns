package edu.ifsp.loja.web.produto;

import edu.ifsp.loja.modelo.Produto;
import edu.ifsp.loja.persistencia.dao.ProdutoDAO;
import edu.ifsp.loja.persistencia.factory.DatabaseFactory;
import edu.ifsp.loja.persistencia.factory.DatabaseFactoryProducer;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/listarProdutos")
public class PesquisarProdutoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            DatabaseFactory factory = DatabaseFactoryProducer.getFactory();
            ProdutoDAO produtoDAO = factory.createProdutoDAO();
            List<Produto> produtos = produtoDAO.listar();

            request.setAttribute("produtos", produtos);
            request.getRequestDispatcher("/produto/lista.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Erro ao listar produtos", e);
        }
    }
}
