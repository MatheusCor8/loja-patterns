package edu.ifsp.loja.persistencia.dao;

import edu.ifsp.loja.modelo.Cliente;
import java.util.List;

public interface ClienteDAO {
    void salvar(Cliente cliente);
    Cliente buscarPorId(int id);
    List<Cliente> listarTodos();
}
