package edu.ifsp.loja.web.produto;

import edu.ifsp.loja.modelo.Produto;
import edu.ifsp.loja.persistencia.dao.ProdutoDAO;
import edu.ifsp.loja.persistencia.factory.DatabaseFactory;
import edu.ifsp.loja.persistencia.factory.DatabaseFactoryProducer;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/cadastrarProduto")
public class CadastrarProdutoServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String nome = request.getParameter("nome");
        double preco = Double.parseDouble(request.getParameter("preco"));

        Produto produto = new Produto();
        produto.setNome(nome);
        produto.setPreco(preco);

        try {
            DatabaseFactory factory = DatabaseFactoryProducer.getFactory();
            ProdutoDAO produtoDAO = factory.createProdutoDAO();
            produtoDAO.inserir(produto);

            response.sendRedirect("listarProdutos");
        } catch (SQLException e) {
            throw new ServletException("Erro ao cadastrar produto", e);
        }
    }
}
