package edu.ifsp.loja.persistencia.factory;

import edu.ifsp.loja.persistencia.dao.ClienteDAO;
import edu.ifsp.loja.persistencia.dao.ProdutoDAO;

public interface DatabaseFactory {
    ClienteDAO createClienteDAO();
    ProdutoDAO createProdutoDAO();
}
