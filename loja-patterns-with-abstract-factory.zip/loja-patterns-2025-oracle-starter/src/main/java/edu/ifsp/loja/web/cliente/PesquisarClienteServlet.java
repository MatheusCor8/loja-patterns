package edu.ifsp.loja.web.cliente;

import edu.ifsp.loja.modelo.Cliente;
import edu.ifsp.loja.persistencia.dao.ClienteDAO;
import edu.ifsp.loja.persistencia.factory.DatabaseFactory;
import edu.ifsp.loja.persistencia.factory.DatabaseFactoryProducer;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/pesquisarCliente")
public class PesquisarClienteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            DatabaseFactory factory = DatabaseFactoryProducer.getFactory();
            ClienteDAO clienteDAO = factory.createClienteDAO();
            List<Cliente> clientes = clienteDAO.listar();

            request.setAttribute("clientes", clientes);
            request.getRequestDispatcher("/cliente/lista.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Erro ao listar clientes", e);
        }
    }
}
