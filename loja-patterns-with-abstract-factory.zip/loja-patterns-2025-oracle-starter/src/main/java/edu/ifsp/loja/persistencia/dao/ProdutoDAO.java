package edu.ifsp.loja.persistencia.dao;

import edu.ifsp.loja.modelo.Produto;
import java.util.List;

public interface ProdutoDAO {
    void salvar(Produto produto);
    Produto buscarPorId(int id);
    List<Produto> listarTodos();
}
